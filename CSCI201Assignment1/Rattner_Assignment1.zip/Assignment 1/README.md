Assignment 1 README
run UI to run the program